# **BusTrack**
> Uber like Bus Tracking app.(ANDROID APP)

Many students face problems related to college bus like, College bus tracking, requesting driver to wait because many times we have to run in order to catch the bus without any gurantee that we'd be able to catch the bus, so here with this app we can ask the driver to wait by just clicking a view, and everything is handle intelligently.


We are building an Uber like Android app which will provide real time location and ETA of college buses. App has two faces driver side and student side.
App also have online bus routes.
App is intelligent enough to handle both the cases, that is single app will be made for driver side and riders side.

We have used firebase as our backend and Google Location API, Maps API and GeoFire to query all geo location all over the firbase database.

**BusTrack Technological Stack:**

Firebase 
Google Location API 
Google Maps API      
GeoFire		    
ButterKnife 		   
Timber 		    
Firebase Auth	   
Firebase Database  
Android Studio

**Screenshots**
![bustrack1](https://user-images.githubusercontent.com/21143936/34864286-95773e76-f799-11e7-8d66-84f384773080.png)

__Snapshot of the Firebase Database(For one college, Similar for another college that signs up!)__
![image](https://user-images.githubusercontent.com/21143936/34864438-446d6dba-f79a-11e7-84a6-ffd847fae7f0.png)

## **Contributing**

All the contributions are most welcome.

